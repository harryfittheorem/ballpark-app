# Infinite Hitting · Platform Demo

Three prototypes unified into one deployable demo site:

- **Athlete App** (mobile) — Home · Work · Book · Earn · Me
- **Operations Portal** (desktop) — Owner / Coach / Franchisor roles
- **AI Layer** (scrollable pitch) — SMS operations intelligence

Navigation between the three is handled via a persistent top nav. Landing page introduces all three.

---

## Option A: Deploy to Netlify (easiest, ~5 minutes)

1. **Zip this entire folder**
2. Go to **[netlify.com/drop](https://app.netlify.com/drop)** (no account needed to start)
3. Drag the zip onto the page
4. Netlify will auto-detect the Vite project and deploy it
5. You'll get a URL like `https://graceful-elf-abc123.netlify.app`
6. Click "Site settings" → "Change site name" → rename to something like `infinitehitting-demo`
7. Your final URL: `https://infinitehitting-demo.netlify.app`

Alternatively, connect via Git:
1. Push this folder to a GitHub repo
2. In Netlify: "Add new site" → "Import existing project" → pick your repo
3. Build command: `npm run build`, Publish directory: `dist`

### Custom domain (optional — makes it look like a real product)

1. Buy a domain (Namecheap, Google Domains, etc.) — maybe `ballpark.app` or use a subdomain of `myagencyos.com`
2. In Netlify: "Domain settings" → "Add a domain"
3. Follow DNS instructions
4. Netlify gives you free SSL automatically

Result: `https://demo.myagencyos.com` instead of `claude.ai/public/artifacts/...`

---

## Option B: Test locally first

```bash
npm install
npm run dev
```

Opens at `http://localhost:5173`. Click around to make sure all three demos work before deploying.

To build for production:

```bash
npm run build
```

Creates a `dist/` folder you can deploy anywhere — Netlify, Vercel, Cloudflare Pages, GitHub Pages, AWS S3, etc.

---

## URL structure

- `yourdomain.com/` → Landing page (three product intros)
- `yourdomain.com/#/athlete` → Athlete app prototype
- `yourdomain.com/#/portal` → Operations portal
- `yourdomain.com/#/ai` → AI layer pitch

Navigate between them via the top nav bar (persistent across all three).

---

## File structure

```
ih-demo/
├── public/
│   └── favicon.svg           ← IH gold-on-dark favicon
├── src/
│   ├── main.jsx              ← React entry point
│   ├── App.jsx               ← Landing page + router
│   ├── AthleteApp.jsx        ← Athlete mobile app (32 screens)
│   ├── Portal.jsx            ← Ops portal (15 screens)
│   └── AILayer.jsx           ← AI layer pitch (5 sections)
├── index.html                ← HTML template w/ font preload
├── package.json              ← Dependencies
├── vite.config.js            ← Vite config
├── netlify.toml              ← Netlify deploy config
└── README.md                 ← This file
```

---

## If you want to share a single direct link

For most demos, just share the root URL and let them navigate. But if you want to send someone directly into one product:

- `yourdomain.com/#/athlete` → drops them into the athlete app
- `yourdomain.com/#/portal` → drops them into the portal
- `yourdomain.com/#/ai` → drops them into the AI layer

The top nav stays visible so they can switch.
