import React, { useState, useEffect } from 'react';
import { Smartphone, Monitor, Sparkles, ArrowRight, ChevronLeft, Dumbbell, Zap, BarChart3, MessageSquare, Home, ExternalLink } from 'lucide-react';
import AthleteApp from './AthleteApp.jsx';
import Portal from './Portal.jsx';
import AILayer from './AILayer.jsx';

const brand = {
  dark: '#2D2B2A',
  darker: '#1C1B1A',
  darkest: '#0F0E0E',
  gold: '#F1E5AD',
  goldBright: '#E8D89A',
  goldDeep: '#B8A268',
  cream: '#FAF6E8',
  white: '#FFFFFF',
  muted: '#6B6560',
  border: '#3A3836',
  borderGold: 'rgba(241, 229, 173, 0.2)',
};

const fonts = {
  display: "'Oswald', 'Bebas Neue', Impact, sans-serif",
  body: "'Inter', -apple-system, sans-serif",
};

// ============================================
// HASH-BASED ROUTER
// ============================================
const useHashRoute = () => {
  const [route, setRoute] = useState(() => window.location.hash.replace('#/', '') || 'home');

  useEffect(() => {
    const handler = () => {
      setRoute(window.location.hash.replace('#/', '') || 'home');
      window.scrollTo(0, 0);
    };
    window.addEventListener('hashchange', handler);
    return () => window.removeEventListener('hashchange', handler);
  }, []);

  const navigate = (path) => {
    window.location.hash = `/${path}`;
  };

  return [route, navigate];
};

// ============================================
// TOP NAV BAR (persistent across all demos)
// ============================================
const TopNav = ({ current, navigate }) => {
  const items = [
    { id: 'athlete', label: 'Athlete App', icon: Smartphone },
    { id: 'portal', label: 'Operations Portal', icon: Monitor },
    { id: 'ai', label: 'AI Layer', icon: Sparkles },
  ];

  return (
    <div style={{
      position: 'sticky', top: 0, zIndex: 100,
      background: 'rgba(15, 14, 14, 0.92)',
      backdropFilter: 'blur(24px)',
      borderBottom: `1px solid ${brand.border}`,
      padding: '12px 24px',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
    }}>
      <div onClick={() => navigate('home')} style={{ display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer' }}>
        <div style={{ width: 32, height: 32, borderRadius: 8, background: brand.gold, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <Dumbbell size={16} color={brand.dark} strokeWidth={2.5} />
        </div>
        <div>
          <div style={{ fontSize: 11, fontWeight: 800, color: brand.gold, letterSpacing: 2, fontFamily: fonts.display, lineHeight: 1 }}>INFINITE HITTING</div>
          <div style={{ fontSize: 8, fontWeight: 600, color: brand.muted, letterSpacing: 1.5, marginTop: 2 }}>PLATFORM DEMO</div>
        </div>
      </div>

      <div style={{ display: 'flex', gap: 4 }}>
        {items.map(item => {
          const active = current === item.id;
          return (
            <div key={item.id} onClick={() => navigate(item.id)} style={{
              padding: '8px 14px', borderRadius: 8,
              background: active ? brand.gold : 'transparent',
              color: active ? brand.dark : brand.muted,
              fontSize: 12, fontWeight: 700, letterSpacing: 0.5,
              cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6,
              transition: 'all 0.15s',
              fontFamily: fonts.body,
            }}>
              <item.icon size={14} />
              <span>{item.label}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
};

// ============================================
// LANDING PAGE
// ============================================
const Landing = ({ navigate }) => {
  const demos = [
    {
      id: 'athlete',
      label: 'ATHLETE APP',
      title: 'For the kid.\nFor the parent.',
      description: 'Mobile-first engagement platform where kids review their swings, complete coach assignments, redeem rewards, and book sessions. Built for daily use.',
      stats: [
        { label: 'Screens', value: '32' },
        { label: 'Tabs', value: '5' },
        { label: 'Data model', value: 'Full' },
      ],
      icon: Smartphone,
      gradient: `linear-gradient(135deg, ${brand.gold} 0%, ${brand.goldBright} 100%)`,
      highlights: [
        'Unified text + video messaging with coaches',
        'Session-by-session swing review with HitTrax data',
        'Points-and-dollars dual-pricing store',
        'Book lessons, classes, and cage time in-app',
      ],
    },
    {
      id: 'portal',
      label: 'OPERATIONS PORTAL',
      title: 'For the owner.\nFor the franchisor.',
      description: 'Desktop-first operations and intelligence dashboard. Three role views — coach, owner, franchisor. Handles CRM, billing, retention, scheduling, and network-level analytics.',
      stats: [
        { label: 'Screens', value: '15' },
        { label: 'Roles', value: '3' },
        { label: 'KPI views', value: '20+' },
      ],
      icon: Monitor,
      gradient: `linear-gradient(135deg, ${brand.dark} 0%, ${brand.darker} 100%)`,
      highlights: [
        'Cohort retention heatmap — see churn before it happens',
        'Financial forecast with EFT/OTC breakdown',
        'At-risk member detection + churn analysis',
        'Franchisor network dashboard with cross-location benchmarking',
      ],
    },
    {
      id: 'ai',
      label: 'AI LAYER',
      title: 'For the other\n23 hours 50 minutes.',
      description: 'Proactive operations intelligence that texts owners the moment something matters. Payment failures, coach no-shows, at-risk members, daily recaps — all via SMS.',
      stats: [
        { label: 'Scenarios', value: '6' },
        { label: 'Channels', value: '4' },
        { label: 'Response', value: '<30s' },
      ],
      icon: Sparkles,
      gradient: `linear-gradient(135deg, ${brand.goldDeep} 0%, ${brand.dark} 100%)`,
      highlights: [
        'Real-time payment recovery via SMS reply',
        'Two-way Q&A on business data from your phone',
        'Daily 8 PM recap text — wins, concerns, context',
        'Franchisor network intelligence digest',
      ],
    },
  ];

  return (
    <div style={{ background: brand.darkest, minHeight: '100vh', color: brand.cream }}>
      {/* Hero */}
      <div style={{
        padding: '80px 24px 60px',
        maxWidth: 1200, margin: '0 auto',
        position: 'relative',
      }}>
        <div style={{ fontSize: 11, fontWeight: 800, color: brand.gold, letterSpacing: 3, fontFamily: fonts.display, marginBottom: 20 }}>
          INTRODUCING · THE OPERATING SYSTEM FOR YOUTH SPORTS FACILITIES
        </div>
        <h1 style={{
          fontSize: 'clamp(48px, 8vw, 84px)', fontWeight: 700, fontFamily: fonts.display,
          letterSpacing: -2, lineHeight: 0.95, margin: '0 0 32px 0',
          color: brand.white, maxWidth: 900,
        }}>
          Three products.<br/>
          <span style={{ color: brand.gold }}>One platform.</span>
        </h1>
        <p style={{ fontSize: 20, color: brand.cream, lineHeight: 1.5, maxWidth: 640, opacity: 0.85, margin: 0 }}>
          Built for Infinite Hitting to replace MindBody, GolfTec, and your spreadsheet — and give your franchise network the intelligence it actually needs.
        </p>
      </div>

      {/* Product cards */}
      <div style={{
        maxWidth: 1200, margin: '0 auto',
        padding: '0 24px 80px',
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(340px, 1fr))',
        gap: 20,
      }}>
        {demos.map(demo => (
          <div key={demo.id}
            onClick={() => navigate(demo.id)}
            style={{
              background: brand.darker,
              borderRadius: 20,
              overflow: 'hidden',
              border: `1px solid ${brand.border}`,
              cursor: 'pointer',
              transition: 'transform 0.2s, border-color 0.2s',
            }}
            onMouseEnter={e => { e.currentTarget.style.borderColor = brand.gold; e.currentTarget.style.transform = 'translateY(-4px)'; }}
            onMouseLeave={e => { e.currentTarget.style.borderColor = brand.border; e.currentTarget.style.transform = 'translateY(0)'; }}
          >
            {/* Top visual band */}
            <div style={{ height: 160, background: demo.gradient, position: 'relative', overflow: 'hidden', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <demo.icon size={64} color={demo.id === 'athlete' ? brand.dark : brand.gold} strokeWidth={1.5} />
              <div style={{ position: 'absolute', top: 16, left: 16, fontSize: 9, fontWeight: 800, color: demo.id === 'athlete' ? brand.dark : brand.gold, letterSpacing: 2, fontFamily: fonts.display, opacity: 0.8 }}>
                {demo.label}
              </div>
            </div>

            {/* Content */}
            <div style={{ padding: 24 }}>
              <h2 style={{ fontSize: 26, fontWeight: 700, fontFamily: fonts.display, letterSpacing: -0.5, lineHeight: 1.1, margin: '0 0 12px 0', color: brand.white, whiteSpace: 'pre-line' }}>
                {demo.title}
              </h2>
              <p style={{ fontSize: 13, color: brand.muted, lineHeight: 1.6, margin: '0 0 18px 0' }}>
                {demo.description}
              </p>

              {/* Stats row */}
              <div style={{ display: 'flex', gap: 16, marginBottom: 18, paddingBottom: 16, borderBottom: `1px solid ${brand.border}` }}>
                {demo.stats.map(s => (
                  <div key={s.label}>
                    <div style={{ fontSize: 18, fontWeight: 700, fontFamily: fonts.display, color: brand.gold, lineHeight: 1 }}>{s.value}</div>
                    <div style={{ fontSize: 8, color: brand.muted, fontWeight: 700, letterSpacing: 1.5, marginTop: 4, fontFamily: fonts.display }}>{s.label.toUpperCase()}</div>
                  </div>
                ))}
              </div>

              {/* Highlights */}
              <div style={{ marginBottom: 20 }}>
                {demo.highlights.map((h, i) => (
                  <div key={i} style={{ display: 'flex', gap: 8, marginBottom: 8, fontSize: 12, color: brand.cream, lineHeight: 1.5 }}>
                    <div style={{ width: 4, height: 4, borderRadius: 2, background: brand.gold, marginTop: 6, flexShrink: 0 }} />
                    <div>{h}</div>
                  </div>
                ))}
              </div>

              {/* CTA */}
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, color: brand.gold, fontSize: 12, fontWeight: 800, letterSpacing: 1, fontFamily: fonts.display }}>
                OPEN PROTOTYPE <ArrowRight size={14} />
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* How they fit together */}
      <div style={{ maxWidth: 1200, margin: '0 auto', padding: '0 24px 80px' }}>
        <div style={{ background: `linear-gradient(135deg, ${brand.darker} 0%, ${brand.dark} 100%)`, borderRadius: 20, padding: 40, border: `1px solid ${brand.borderGold}` }}>
          <div style={{ fontSize: 11, fontWeight: 800, color: brand.gold, letterSpacing: 3, fontFamily: fonts.display, marginBottom: 16 }}>
            HOW THEY FIT TOGETHER
          </div>
          <h2 style={{ fontSize: 36, fontWeight: 700, fontFamily: fonts.display, letterSpacing: -0.8, color: brand.white, margin: '0 0 24px 0', lineHeight: 1.1 }}>
            Three products, built to work as one.
          </h2>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: 20 }}>
            {[
              { title: 'Athletes & Parents', desc: 'Mobile app drives daily engagement, homework completion, and bookings.', icon: Smartphone },
              { title: 'Coaches & Owners', desc: 'Portal runs the business — members, billing, retention, scheduling.', icon: Monitor },
              { title: 'Franchisors', desc: 'AI layer delivers real-time intelligence to owners and network insights to HQ.', icon: Sparkles },
            ].map((c, i) => (
              <div key={i} style={{ padding: '20px 0' }}>
                <div style={{ width: 40, height: 40, borderRadius: 10, background: `${brand.gold}15`, display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 14 }}>
                  <c.icon size={20} color={brand.gold} />
                </div>
                <div style={{ fontSize: 14, fontWeight: 700, color: brand.white, marginBottom: 6 }}>{c.title}</div>
                <div style={{ fontSize: 12, color: brand.muted, lineHeight: 1.6 }}>{c.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Footer */}
      <div style={{ borderTop: `1px solid ${brand.border}`, padding: '32px 24px', textAlign: 'center', color: brand.muted, fontSize: 11 }}>
        Design preview · Prototype · {new Date().getFullYear()}
      </div>
    </div>
  );
};

// ============================================
// DEMO WRAPPER (adds "back" breadcrumb + proper container)
// ============================================
const DemoWrapper = ({ children, title, navigate }) => (
  <div style={{ minHeight: '100vh', background: brand.darkest }}>
    {children}
  </div>
);

// ============================================
// MAIN APP
// ============================================
export default function App() {
  const [route, navigate] = useHashRoute();

  const current = route === 'athlete' || route === 'portal' || route === 'ai' ? route : 'home';

  return (
    <div style={{ fontFamily: fonts.body, background: brand.darkest, minHeight: '100vh' }}>
      <TopNav current={current} navigate={navigate} />
      {current === 'home' && <Landing navigate={navigate} />}
      {current === 'athlete' && (
        <DemoWrapper title="Athlete App" navigate={navigate}>
          <AthleteApp />
        </DemoWrapper>
      )}
      {current === 'portal' && (
        <DemoWrapper title="Operations Portal" navigate={navigate}>
          <Portal />
        </DemoWrapper>
      )}
      {current === 'ai' && (
        <DemoWrapper title="AI Layer" navigate={navigate}>
          <AILayer />
        </DemoWrapper>
      )}
    </div>
  );
}
